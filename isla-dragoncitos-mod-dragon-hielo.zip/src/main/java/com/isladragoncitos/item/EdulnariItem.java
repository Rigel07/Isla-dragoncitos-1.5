package com.isladragoncitos.item;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import com.isladragoncitos.registry.ModItems;

/**
 * Edulnari: esencia draconiana que deja un dragon al morir. Guarda sus niveles y habilidades (no el tamano ni las
 * escamas). Clic derecho sobre un huevo de dragon (antes de que eclosione) para traspasarsela al nuevo dragon.
 */
public class EdulnariItem extends Item {
    public EdulnariItem(Properties properties) {
        super(properties);
    }

    public static ItemStack create(int strength, int health, int speed, boolean shared, int origin) {
        ItemStack stack = new ItemStack(ModItems.EDULNARI.get());
        CompoundTag tag = stack.getOrCreateTag();
        tag.putInt("Strength", strength);
        tag.putInt("Health", health);
        tag.putInt("Speed", speed);
        tag.putBoolean("Shared", shared);
        tag.putInt("Origin", origin);
        return stack;
    }

    /** Reconstruye la esencia a partir de los datos guardados en un huevo. */
    public static ItemStack fromEssence(CompoundTag essence) {
        return create(essence.getInt("Strength"), essence.getInt("Health"), essence.getInt("Speed"),
                essence.getBoolean("Shared"), essence.getInt("Origin"));
    }

    public static boolean hasData(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains("Strength");
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (!hasData(stack)) {
            tooltip.add(Component.translatable("tooltip.isladragoncitos.edulnari.empty").withStyle(ChatFormatting.GRAY));
            return;
        }
        CompoundTag tag = stack.getTag();
        String[] types = {"Fuego", "Hielo", "Tormenta", "Agua"};
        tooltip.add(Component.literal("Dragón de " + types[Math.max(0, Math.min(3, tag.getInt("Origin")))])
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("Fuerza " + tag.getInt("Strength") + "  Velocidad " + tag.getInt("Speed")
                + "  Vida " + tag.getInt("Health")).withStyle(ChatFormatting.GRAY));
        if (tag.getBoolean("Shared")) {
            tooltip.add(Component.literal("Vida compartida").withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.isladragoncitos.edulnari.use").withStyle(ChatFormatting.DARK_GRAY));
    }
}
