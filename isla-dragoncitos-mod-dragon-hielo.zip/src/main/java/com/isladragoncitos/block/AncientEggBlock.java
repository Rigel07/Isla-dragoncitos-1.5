package com.isladragoncitos.block;

import com.isladragoncitos.item.EdulnariItem;
import com.isladragoncitos.registry.ModBlockEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Huevo de dragon antiguo. Al colocarlo con un jugador cerca, eclosiona en un dragon domado. */
public class AncientEggBlock extends BaseEntityBlock {
    private static final VoxelShape SHAPE = net.minecraft.world.level.block.Block.box(3.0D, 0.0D, 3.0D, 13.0D, 15.0D, 13.0D);
    private final int type;

    public AncientEggBlock(Properties properties, int type) {
        super(properties);
        this.type = type;
    }

    public int getDragonType() {
        return this.type;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AncientEggBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return createTickerHelper(type, ModBlockEntities.ANCIENT_EGG.get(), AncientEggBlockEntity::serverTick);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof AncientEggBlockEntity egg) {
            egg.setOwner(player.getUUID());
        }
    }

    /** Clic derecho con un edulnari: traspasa la esencia al dragon que va a nacer. */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof EdulnariItem) || !EdulnariItem.hasData(stack)
                || !(level.getBlockEntity(pos) instanceof AncientEggBlockEntity egg)) {
            return InteractionResult.PASS;
        }
        if (egg.hasEssence()) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.literal("Este huevo ya tiene una esencia."), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            egg.setEssence(stack.getTag().copy());
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 0.6D, pos.getZ() + 0.5D,
                        25, 0.25D, 0.4D, 0.25D, 0.05D);
            }
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.literal("La esencia late dentro del huevo: el dragón nacerá con sus habilidades."), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Si rompes el huevo con una esencia dentro, esta no se pierde. */
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof AncientEggBlockEntity egg && egg.hasEssence()) {
            popResource(level, pos, EdulnariItem.fromEssence(egg.takeEssence()));
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(6) != 0) {
            return;
        }
        ParticleOptions particle = this.type == 0 ? ParticleTypes.SMALL_FLAME
                : (this.type == 1 ? ParticleTypes.SNOWFLAKE : (this.type == 3 ? ParticleTypes.BUBBLE_POP : ParticleTypes.ELECTRIC_SPARK));
        level.addParticle(particle, pos.getX() + 0.3D + random.nextDouble() * 0.4D, pos.getY() + 0.4D + random.nextDouble() * 0.6D,
                pos.getZ() + 0.3D + random.nextDouble() * 0.4D, 0.0D, 0.02D, 0.0D);
    }
}
