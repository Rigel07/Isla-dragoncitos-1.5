package com.isladragoncitos.worldgen;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;

/** La Cronica de los Jinetes del Alba: la historia de la civilizacion desaparecida (generado a partir del texto original). */
public final class RiderLore {
    public static final TagKey<Structure> RUINS =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(IslaDragoncitosMod.MODID, "rider_ruins"));
    public static final String AUTHOR = "Naru, la \u00daltima Cronista";
    public static final String[] TITLES = {
        "I. El Primer Huevo",
        "II. Los Cuatro Alientos",
        "III. Los Hijos Peque\u00f1os",
        "IV. Las Islas Altas",
        "V. El Pacto de Un Solo Coraz\u00f3n",
        "VI. La Marea Gris",
        "VII. El \u00daltimo Vuelo",
        "VIII. Carta de Naru"
    };
    public static final String[][] PAGES = {
        {
            "Antes de las islas y antes de los nombres, el cielo estaba vac\u00edo y la tierra ten\u00eda hambre de alas. Cuentan que Ithara, una pastora de las colinas del Alba, sigui\u00f3 un latido que sonaba bajo la hierba.",
            "Cav\u00f3 con las manos hasta hallar un huevo tibio, grande como un cordero. Lo cuid\u00f3 durante tres inviernos. Cuando eclosion\u00f3, el drag\u00f3n no rugi\u00f3: la mir\u00f3 y apoy\u00f3 la frente en su pecho.",
            "As\u00ed naci\u00f3 el primer v\u00ednculo, y en la piel de Ithara apareci\u00f3 una marca con forma de ala. La llamaron la Marca del Jinete."
        },
        {
            "Ithara no fue la \u00fanica en o\u00edr los latidos. Bajo las brasas de los volcanes dorm\u00eda el huevo del Aliento de Fuego. En las cumbres heladas, el del Aliento de Ventisca. En las nubes negras, el del Aliento de Rayo.",
            "Y en lo m\u00e1s hondo del oc\u00e9ano, donde la luz no llega, lat\u00eda el del Aliento de Mar, el m\u00e1s antiguo y el m\u00e1s raro. Los jinetes dec\u00edan que ese \u00faltimo jam\u00e1s se dej\u00f3 encontrar por quien lo buscaba con codicia:",
            "solo por quien no tem\u00eda a la oscuridad."
        },
        {
            "Los grandes dragones mudaban escamas al crecer, y cada escama que tocaba la tierra guardaba un eco de su coraz\u00f3n.",
            "De las escamas rosas nacieron los dragoncitos que cantan; de las verdes, los que hacen florecer la piedra; de las azules, los que oyen el mar; de las rojas, los que nunca pasan fr\u00edo. Son los hijos peque\u00f1os.",
            "Nunca crecen, y por eso los grandes dragones los adoran como se adora lo que no se quiere perder. A\u00fan hoy, un dragoncito se inclina ante un drag\u00f3n antiguo."
        },
        {
            "Cuando la Marea Gris amenaz\u00f3 los valles, los jinetes cantaron el Canto del Alba y alzaron pedazos de tierra al cielo: islas con lago, cascada y una estatua de drag\u00f3n en el centro.",
            "Cada isla recib\u00eda el nombre que le daba su guardi\u00e1n, y cada nombre era un camino: el drag\u00f3n conoce el nombre y vuela hacia \u00e9l con los ojos cerrados.",
            "Dejaron cofres para quienes vinieran despu\u00e9s, y un instrumento de oro y escamas, la br\u00fajula que huele islas, para que ninguna se perdiera."
        },
        {
            "Hubo jinetes que pidieron m\u00e1s que volar. Pidieron compartir el latido. El pacto costaba cien destellos de cielo descubierto, cien islas recordadas.",
            "Quien lo sellaba y su drag\u00f3n sumaban sus vidas en una sola, y eran un \u00fanico coraz\u00f3n del color del drag\u00f3n. Pero el pacto ten\u00eda una ley cruel: si uno ca\u00eda, ca\u00eda el otro. Los jinetes pod\u00edan renacer al amanecer; los dragones, nunca.",
            "Por eso la Marca del Jinete solo vive mientras vive el drag\u00f3n que la despert\u00f3."
        },
        {
            "No fue un enemigo con rostro. Fue una niebla sin sonido que apagaba los colores y el canto de los pueblos. Donde pasaba, las escamas perd\u00edan brillo y los huevos dejaban de latir.",
            "Los jinetes la combatieron con fuego, con hielo, con rayo y con agua, pero la marea no ten\u00eda cuerpo que herir. Ithara, ya anciana, descubri\u00f3 su origen: una grieta en el borde del cielo de donde sal\u00eda el silencio.",
            "Sellarla exig\u00eda que todos los dragones cantaran a la vez."
        },
        {
            "Al amanecer m\u00e1s largo de la historia, todos los jinetes montaron. Las islas quedaron vac\u00edas, los cofres cerrados, los pueblos en silencio. Los dragones ascendieron en espiral hasta que dejaron de verse.",
            "Se oy\u00f3 un canto tan hondo que los lagos temblaron, y luego nada. Ninguna ala volvi\u00f3. Nadie sabe si la grieta se sell\u00f3 o si el cielo los guard\u00f3 para siempre.",
            "Solo quedaron los hijos peque\u00f1os, esperando en las islas sin entender por qu\u00e9 nadie bajaba."
        },
        {
            "Soy Naru, la \u00faltima cronista. No vol\u00e9: alguien deb\u00eda quedarse a contarlo. Antes de partir, los jinetes me pidieron esconder los huevos semilla:",
            "uno bajo las colinas, uno entre las cumbres, uno en las tormentas y uno en el abismo del mar. Los cubr\u00ed de musgo y piedra. Si lees esto, tu coraz\u00f3n late m\u00e1s fuerte de lo normal, y lo har\u00e1 m\u00e1s cerca de ellos.",
            "Alim\u00e9ntalos, n\u00f3mbralos, cu\u00eddalos. El Alba no termin\u00f3: espera a su pr\u00f3ximo jinete."
        }
    };

    private RiderLore() {}

    public static int chapters() {
        return TITLES.length;
    }

    /** Capitulo de la cronica como libro escrito. */
    public static ItemStack book(int chapter) {
        int i = Math.floorMod(chapter, TITLES.length);
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putString("title", TITLES[i]);
        tag.putString("author", AUTHOR);
        ListTag pages = new ListTag();
        for (String page : PAGES[i]) {
            pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(page))));
        }
        tag.put("pages", pages);
        return stack;
    }

    /** Indice del capitulo si el objeto es un libro de la cronica, o -1. */
    public static int chapterOf(ItemStack stack) {
        if (!stack.is(Items.WRITTEN_BOOK) || !stack.hasTag()) {
            return -1;
        }
        String title = stack.getTag().getString("title");
        for (int i = 0; i < TITLES.length; i++) {
            if (TITLES[i].equals(title)) {
                return i;
            }
        }
        return -1;
    }

    /** Coloca un atril con un capitulo de la cronica abierto encima. */
    public static void placeLectern(WorldGenLevel level, BoundingBox box, BlockPos pos, Direction facing, int chapter) {
        if (!box.isInside(pos)) {
            return;
        }
        level.setBlock(pos, Blocks.LECTERN.defaultBlockState()
                .setValue(LecternBlock.FACING, facing).setValue(LecternBlock.HAS_BOOK, true), 2);
        BlockEntity entity = level.getBlockEntity(pos);
        if (entity instanceof LecternBlockEntity lectern) {
            lectern.setBook(book(chapter));
        }
    }
}
