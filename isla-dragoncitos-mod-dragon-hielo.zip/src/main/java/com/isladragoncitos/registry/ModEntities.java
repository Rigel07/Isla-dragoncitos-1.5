package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.entity.DragoncitoEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, IslaDragoncitosMod.MODID);

    public static final RegistryObject<EntityType<DragoncitoEntity>> DRAGONCITO = ENTITY_TYPES.register("dragoncito",
            () -> EntityType.Builder.<DragoncitoEntity>of(DragoncitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.7F)
                    .clientTrackingRange(8)
                    .build(IslaDragoncitosMod.MODID + ":dragoncito"));

    public static final RegistryObject<EntityType<AncientDragonEntity>> ANCIENT_DRAGON = ENTITY_TYPES.register("ancient_dragon",
            () -> EntityType.Builder.<AncientDragonEntity>of(AncientDragonEntity::new, MobCategory.CREATURE)
                    .sized(1.6F, 1.5F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .build(IslaDragoncitosMod.MODID + ":ancient_dragon"));

    private ModEntities() {}
}
